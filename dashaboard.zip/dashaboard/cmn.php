<?php 
include("includes/header.php"); 
include("includes/navbar.php");
include("includes/sidebar.php");


    
    
?>




	<!-- CONTENT -->
	<section id="content">
		
	
		<!-- MAIN -->
		<main>
			
			
			<div class="table-data">
				<div class="order">
					<div class="head">
						<h3>Find Tutor</h3>
						<i class='bx bx-search' ></i>
						<i class='bx bx-filter' ></i>
					</div>
					<table>
						<thead>
							<tr>
								<th>Tutors</th>
								<th>Module</th>
								<a href="contact.php">Contact Details</a>
								
							</tr>
						</thead>
						<tbody>
							<tr>
								<td>
									<img src="john.jpg">
									<p>062 006 6482</p>
								</td>
								<td>BAY</td>
							
							</tr>
							<tr>
								<td>
									<img src="banele.jpg">
									<p>072 452 3189</p>
								</td>
								<td>BAY</td>
								
							<tr>
								<td>
									<img src="jerry.jpg">
									<p>073 717 2239</p>
								</td>
								<td>DSW</td>
								
							</tr>
							<tr>
								<td>
									<img src="boitumelo.jpg">
									<p>082 301 5002</p>
								</td>
								<td>DSW</td>
								
							</tr>
							<tr>
								<td>
									<img src="lindiwe.jpg">
									<p>079 468 2390</p>
								</td>
								<td>CMN</td>
							
							</tr>
							<tr>
								<td>
									<img src="palesa.jpg">
									<p>066 207 2024</p>
								</td>
								<td>CMN</td>
								
							</tr>
							<tr>
								<td>
									<img src="lebogang.jpg">
									<p>081 324 2365</p>
								</td>
								<td>IFS</td>
								
							</tr>
							<tr>
								<td>
									<img src="reabestwe.jpg">
									<p>081 324 5067</p>
								</td>
								<td>IFS</td>
								
							</tr>
						</tbody>
					</table>
				</div>
				
			</div>
			<section>
				
			</section>
		</main>
		<!-- MAIN -->
	</section>
	<!-- CONTENT -->

    <?php
    include("includes/scripts.php");
    include("includes/footer.php");
    ?>

