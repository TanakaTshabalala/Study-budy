<?php
include("includes/header.php"); 
include("includes/navbar.php");
include("includes/sidebar.php");
$conn=new PDO('mysql:host=localhost; dbname=adminpanel', 'root', '') or die(mysql_error());
if($_SERVER['REQUEST_METHOD'] == 'GET'){
    $id = $_GET["id"];
    $sql = "SELECT * FROM `upload` WHERE id=$id";
    
}else{
    $name=$_FILES['file']['name'];
    $size=$_FILES['file']['size'];
    $type=$_FILES['file']['type'];
    $temp=$_FILES['file']['tmp_name'];
    // $caption1=$_POST['caption'];
    // $link=$_POST['link'];
    $fname = date("YmdHis").'_'.$name;
    $chk = $conn->query("UPDATE `upload` SET `fname`='$name',`name`='$fname' WHERE `id`='$id'")->rowCount();
    if($chk){
        $i = 1;
        $c = 0;
        while($c == 0){
            $i++;
            $reversedParts = explode('.', strrev($name), 2);
            $tname = (strrev($reversedParts[1]))."_".($i).'.'.(strrev($reversedParts[0]));
        // var_dump($tname);exit;
            $chk2 = $conn->query("UPDATE `upload` SET `fname`='$name',`name`='$fname' WHERE `id`='$id'")->rowCount();
            if($chk2 == 0){
                $c = 1;
                $name = $tname;
            }
        }
    }
    $move =  move_uploaded_file($temp,"upload/".$fname);
    if($move){
        $query=$conn->query("UPDATE `upload` SET `fname`='$name',`name`='$fname' WHERE `id`='$id'");
        if($query){
        header("location:pastpapers.php");
        }
        else{
        die(mysql_error());
        }
    }
    
   

}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href=" " rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <style>
        
    </style>
    <title>Document</title>
</head>
<body>
<section id="content">
		<main>
    <div class="container my-5">
    <h1><p>Update Files</p></h1>	
        <form enctype="multipart/form-data" action="" name="form" method="post">
				Select File
					<input type="file" name="file" id="file" /></td>
					<input type="submit" name="submit" id="submit" value="Submit" />
		</form>
    </div>
</main>
</section>
</body>
</html>