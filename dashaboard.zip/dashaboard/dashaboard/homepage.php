<?php 
	include("includes/header.php"); 
	include("includes/navbar.php");
	include("includes/sidebar.php");

    
    
?>




	<!-- CONTENT -->
	<section id="content">
		
	
		<!-- MAIN -->
		<main>
			<div class="head-title">
				<div class="left">
					<h1>Tutors</h1>
					<ul class="breadcrumb">
						<li>
							<a href="#">Tutors</a>
						</li>
						<li><i class='bx bx-chevron-right' ></i></li>
						<li>
							<a class="active" href="#">Home</a>
						</li>
					</ul>
				</div>
				<a href="#" class="btn-download">
					<i class='bx bxs-cloud-download' ></i>
					<span class="text">Download PDF</span>
				</a>
			</div>
			<ul class="box-info">
				<li>
					<i class='bx bxs-briefcase-alt-2' ></i>
					<span class="text">
						<h3>Business Analysis</h3>
						<p></p>
					</span>
				</li>
				<li>
					<i class='bx bx-laptop'></i>
					<span class="text">
						<h3>Development Software</h3>
						<p></p>
					</span>
				</li>
                <li>
					<i class='bx bx-wifi-off' ></i>
					<span class="text">
						<h3>Communication Networks</h3>
						<p></p>
					</span>
				</li>
				<li>
					<i class='bx bxs-data' ></i>
					<span class="text">
						<h3>Information Systems</h3>
						<p></p>
					</span>
				</li>
			</ul>
			<div class="table-data">
				<div class="order">
					<div class="head">
						<h3>Recent Orders</h3>
						<i class='bx bx-search' ></i>
						<i class='bx bx-filter' ></i>
					</div>
					<table>
						<thead>
							<tr>
								<th>User</th>
								<th>Date Order</th>
								<th>Status</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td>
									<img src="img/people.png">
									<p>John Doe</p>
								</td>
								<td>01-10-2021</td>
								<td><span class="status completed">Completed</span></td>
							</tr>
							<tr>
								<td>
									<img src="img/people.png">
									<p>John Doe</p>
								</td>
								<td>01-10-2021</td>
								<td><span class="status pending">Pending</span></td>
							</tr>
							<tr>
								<td>
									<img src="img/people.png">
									<p>John Doe</p>
								</td>
								<td>01-10-2021</td>
								<td><span class="status process">Process</span></td>
							</tr>
							<tr>
								<td>
									<img src="img/people.png">
									<p>John Doe</p>
								</td>
								<td>01-10-2021</td>
								<td><span class="status pending">Pending</span></td>
							</tr>
							<tr>
								<td>
									<img src="img/people.png">
									<p>John Doe</p>
								</td>
								<td>01-10-2021</td>
								<td><span class="status completed">Completed</span></td>
							</tr>
						</tbody>
					</table>
				</div>
				<div class="todo">
					<div class="head">
						<h3>Todos</h3>
						<i class='bx bx-plus' ></i>
						<i class='bx bx-filter' ></i>
					</div>
					<ul class="todo-list">
						<li class="completed">
							<p>Todo List</p>
							<i class='bx bx-dots-vertical-rounded' ></i>
						</li>
						<li class="completed">
							<p>Todo List</p>
							<i class='bx bx-dots-vertical-rounded' ></i>
						</li>
						<li class="not-completed">
							<p>Todo List</p>
							<i class='bx bx-dots-vertical-rounded' ></i>
						</li>
						<li class="completed">
							<p>Todo List</p>
							<i class='bx bx-dots-vertical-rounded' ></i>
						</li>
						<li class="not-completed">
							<p>Todo List</p>
							<i class='bx bx-dots-vertical-rounded' ></i>
						</li>
					</ul>
				</div>
			</div>
			<section href=>
				<?php
				?>
			</section>
		</main>
		<!-- MAIN -->
	</section>
	<!-- CONTENT -->

    <?php
    include("includes/script.php");
    include("includes/footer.php");
    ?>