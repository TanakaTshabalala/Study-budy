<?php
session_start();

if (isset($_SESSION["user_id"])) {
    
    $mysqli = mysqli_connect("localhost","root","","adminpanel");
    
    
    $sql = "SELECT * FROM user
            WHERE id = {$_SESSION["user_id"]}";
            
    $result = $mysqli->query($sql);
    
    $user = $result->fetch_assoc();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- Boxicons -->
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>

	<!-- My CSS -->
	<link rel="stylesheet" href="style.css">
	<title>MyStudyBudy</title>
</head>
<body>	
    <!-- NAVBAR -->
    <section id="content">
        <nav>
                    <i class='bx bx-menu' ></i>
                    <a href="#" class="nav-link">Second Year BIT </a>
                    <form action="#">
                        <div class="form-input">
                            <input type="search" placeholder="Search...">
                            <button type="submit" class="search-btn"><i class='bx bx-search' ></i></button>
                        </div>
                    </form>
                    <input type="checkbox" id="switch-mode" hidden>
                    <label for="switch-mode" class="switch-mode"></label>
                    <a href="#" class="notification">
                        <i class='bx bxs-bell' ></i>
                        <span class="num">8</span>
                    </a>
                    <a href="#" class="profile">
                        <i class='bx bxs-user-circle'></i>
                        <p><?= htmlspecialchars($user["name"]) ?></p>
                    </a>
        </nav>

    </section>
  
		<!-- NAVBAR -->

</body>
</html>        