<!-- SIDEBAR -->

    <!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- Boxicons -->
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>

	<!-- My CSS -->
	<link rel="stylesheet" href="style.css">
	<title>MyStudyBudy</title>
</head>
<body>	
    <section id="sidebar">
		<a href="homepage.php" class="brand">
			<i class='bx bxs-book-reader'></i>
			<span class="text">My Study Budy </span>
		</a>
        
    
        
		<ul class="side-menu top">
			<li class="active">
				<a href="homepage.php">
					<i class='bx bxs-happy'></i>
					<span class="text">Module</span>
				</a>
			</li>
			<li>
				<a href="findtutor.php">
                    <i class='bx bx-user-voice'></i>
					<span class="text">Find Tutor</span>
				</a>
			</li>
			
            <li>
				<a href="pastpapers.php">
					<i class='bx bxs-book-open' ></i>
					<span class="text">Past Papers</span>
				</a>
			</li>
			
		</ul>
		<ul class="side-menu">
			<li>
				<a href="#">
					<i class='bx bxs-cog' ></i>
					<span class="text">Settings</span>
				</a>
			</li>
			<li>
            <!-- LOGOUT -->
				<a href="./logout.php" class="logout">
					<i class='bx bxs-log-out-circle' ></i>
					<span class="text">Logout</span>
				</a>
			</li>
		</ul>
	</section>
	<!-- SIDEBAR -->
</body>
</html>       