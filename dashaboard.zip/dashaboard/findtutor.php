<?php 
include("includes/header.php"); 
include("includes/navbar.php");
include("includes/sidebar.php");


    
    
    ?>




	<!-- CONTENT -->
	<section id="content">
		
	
		<!-- MAIN -->
		<main>
			
			
			<div class="table-data">
				<div class="order">
					<div class="head">
						<h3>Find Tutor</h3>
						<i class='bx bx-search' ></i>
						<i class='bx bx-filter' ></i>
					</div>
					<table>
						<thead>
							<tr>
								<th>Tutors</th>
								<th>Module</th>
								<a href="contact.php">Contact Details</a>
								
							</tr>
						</thead>
						<tbody>
							<tr>
								<td>
									<img src="john.jpg">
									<p>John Zikalala</p>
								</td>
								<td>BAY</td>
							
							</tr>
							<tr>
								<td>
									<img src="banele.jpg">
									<p>Banele Mashinini</p>
								</td>
								<td>BAY</td>
								
							<tr>
								<td>
									<img src="jerry.jpg">
									<p>Karabelo Jerry</p>
								</td>
								<td>DSW</td>
								
							</tr>
							<tr>
								<td>
									<img src="boitumelo.jpg">
									<p>Boitumelo Sejoe</p>
								</td>
								<td>DSW</td>
								
							</tr>
							<tr>
								<td>
									<img src="tana.jpg">
									<p>Lindiwe Khuzwayo</p>
								</td>
								<td>CMN</td>
							
							</tr>
							<tr>
								<td>
									<img src="palesa.jpg">
									<p>Palesa Phasha</p>
								</td>
								<td>CMN</td>
								
							</tr>
							<tr>
								<td>
									<img src="lebogang.jpg">
									<p>Lebogang Machepa</p>
								</td>
								<td>IFS</td>
								
							</tr>
							<tr>
								<td>
									<img src="reabestwe.jpg">
									<p>Reabestwe Chabalala</p>
								</td>
								<td>IFS</td>
								
							</tr>
						</tbody>
					</table>
				</div>
				
			</div>
			<section href=>
				
			</section>
		</main>
		<!-- MAIN -->
	</section>
	<!-- CONTENT -->

    <?php
    include("includes/scripts.php");
    include("includes/footer.php");
    ?>