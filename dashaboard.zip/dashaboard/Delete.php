<?php
$mysqli = mysqli_connect("localhost","root","","adminpanel");

if(isset($_GET["id"])){
    $id = $_GET["id"];
    $sql = "DELETE FROM `upload` WHERE id=$id";
    $result= $mysqli->query($sql);
     
    if(!$result){
        echo "failed";
    }else{
        header("Location:pastpapers.php");
    }
    echo "working";

}else{
    echo mysqli_error($mysqli);
}
?>