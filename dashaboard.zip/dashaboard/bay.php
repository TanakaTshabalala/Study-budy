<?php 
include("includes/header.php"); 
include("includes/navbar.php");
include("includes/sidebar.php");


    
    
    ?>




	<!-- CONTENT -->
	<section id="content">
		
	
		<!-- MAIN -->
		<main>
			
			
			<div class="table-data">
				<div class="order">
					<div class="head">
						<h3>Lecturer Details</h3>
						<i class='bx bx-search' ></i>
						<i class='bx bx-filter' ></i>
					</div>
					<table>
						<thead>
							<tr>
								<th>Department of Information Systems </th>
							
							</tr>
						</thead>
						<tbody>
							<tr>
								<td>
									<img src="ntha.jpg">
									<p>Prof Simphiweyinkosi Mbele</p>
									<a href="#">nkosimbele@uj.ac.za</a>
								</td>
								<td> Contact : 076 883 0704 </td>
							</tr>		
						</tbody>
						<tbody>
							<tr>
								<td>
								<li class="active">
									<a href="pastpapers.php">
										<i class='bx bxs-book-alt' ></i>
										<span class="text">Download Study Notes </span>
									</a>
								</li>
								</td>
								<td>  </td>
							</tr>		
						</tbody>
					</table>
				</div>
				
			</div>
			<section href=>
				
			</section>
		</main>
		<!-- MAIN -->
	</section>
	<!-- CONTENT -->

    <?php
    include("includes/scripts.php");
    include("includes/footer.php");
    ?>
