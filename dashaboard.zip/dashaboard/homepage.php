<?php 
include("includes/header.php"); 
include("includes/navbar.php");
include("includes/sidebar.php");


    
    
    ?>




	<!-- CONTENT -->
	<section id="content">
		
	
		<!-- MAIN -->
		<main>
			<div class="head-title">
				<div class="left">
					<h1>Second Year Modules</h1>
					<ul class="breadcrumb">
						<li>
							<a href="homepage.php">MODULES</a>
						</li>
						<li><i class='bx bx-chevron-right' ></i></li>
						<li>
							<a class="active" href="#">Home</a>
						</li>
					</ul>
				</div>
				
			</div>
			<ul class="box-info">
				<li>
					<i class='bx bxs-briefcase-alt-2' ></i>
					<span class="text">
						<h3>Business Analysis</h3>
						<a href="bay.php">more</a>
						<p></p>
					</span>
				</li>
				<li>
						
					<i class='bx bx-laptop'></i>
					<span class="text">
						<h3>Development Software</h3>
						<a href="dsw.php">more</a>
						<p></p>
					</span>
				</li>
                <li>
						
					<i class='bx bx-wifi-off' ></i>
					<span class="text">
						<h3>Communication Networks</h3>
						<a href="cmn.php">more</a>
						<p></p>
					</span>
				</li>
				<li>
						
					<i class='bx bxs-data' ></i>
					<span class="text">
						<h3>Information Systems</h3>
						<a href="ifs.php">more</a>
						<p></p>
					</span>
				</li>
			</ul>
		</main>
		<!-- MAIN -->
	</section>
	<!-- CONTENT -->

    <?php
    include("includes/scripts.php");
    include("includes/footer.php");
    ?>